# MariaDB Ansible Role

Provisions MariaDB end-to-end, covering:

1. Install MariaDB via the OS package manager (apt/dnf).
2. Enable + start the `mariadb` service.
3. Create `/opt/mariadb` as a config directory.
4. Deploy `my.cnf` and `initdb.sql` into that directory (from Jinja2 templates).
5. Restart MariaDB so the new config takes effect.
6. Create an application database.
7. Create an application user with full privileges on that database.
8. Import `initdb.sql` to seed the database.

## Layout

```
mariadb_project/
├── playbook.yml
├── inventory.ini
├── requirements.yml
├── group_vars/
│   └── db_servers/
│       └── vault.yml.example
└── roles/
    └── mariadb/
        ├── defaults/main.yml     # all tunable variables
        ├── vars/
        │   ├── Debian.yml        # apt-based package/service names
        │   └── RedHat.yml        # dnf/yum-based package/service names
        ├── tasks/main.yml        # the 8 steps
        ├── handlers/main.yml     # restart handler
        └── templates/
            ├── my.cnf.j2
            └── initdb.sql.j2
```

## Requirements

- Ansible >= 2.14
- Target host: Debian/Ubuntu or RHEL/CentOS/Rocky family
- Install required collections:

  ```bash
  ansible-galaxy collection install -r requirements.yml
  ```

- `PyMySQL` is installed automatically by the role on the target host (needed
  by the `community.mysql` modules).

## Configure

Edit `roles/mariadb/defaults/main.yml` (or override via `group_vars`/`-e`) to set:

- `mariadb_db_name`, `mariadb_db_user`, `mariadb_db_user_host`
- `mariadb_db_password` — **do not leave the default**; set this via
  Ansible Vault (see `group_vars/db_servers/vault.yml.example`) or `-e`.
- `mariadb_bind_address`, `mariadb_port`, `mariadb_max_connections`,
  `mariadb_innodb_buffer_pool_size` — tuning knobs rendered into `my.cnf`.
- Edit `roles/mariadb/templates/initdb.sql.j2` to match your real schema —
  the shipped version just creates a placeholder `app_info` table.

## Run

```bash
ansible-galaxy collection install -r requirements.yml

ansible-playbook -i inventory.ini playbook.yml \
  --ask-become-pass \
  -e mariadb_db_password='YourStrongPassword'
```

Or, with the password stored in an encrypted vault file:

```bash
ansible-vault encrypt group_vars/db_servers/vault.yml
ansible-playbook -i inventory.ini playbook.yml --ask-become-pass --ask-vault-pass
```

## Notes

- The role symlinks `/opt/mariadb/my.cnf` into the distro's native
  `includedir` (`/etc/mysql/mariadb.conf.d` on Debian, `/etc/my.cnf.d` on
  RedHat) so MariaDB actually reads it — placing a file only in `/opt` would
  otherwise be ignored by the server.
- `mysql_db`/`mysql_user` connect via the local Unix socket (root's
  passwordless local auth, MariaDB's default), so no DB password is needed
  for the Ansible connection itself — only for the new app user you create.
- Set `mariadb_run_initdb: false` if you only want the database created
  without importing seed data.
